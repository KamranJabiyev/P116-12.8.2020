﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBack.DAL;
using FrontToBack.Models;
using FrontToBack.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace FrontToBack.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _db;
        public HomeController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            //HttpContext.Session.SetString("group","P116");
            //Response.Cookies.Append("name", "Ulvi", new CookieOptions { MaxAge = TimeSpan.FromDays(30) });
            HomeVM homeVM = new HomeVM
            {
                PageSign= _db.PageSigns.FirstOrDefault(),
                Sliders= _db.Sliders,
                Categories=_db.Categories,
                About=_db.Abouts.FirstOrDefault(),
                Experts=_db.Experts,
                Subscribe=_db.Subscribes.FirstOrDefault()
            };
            return View(homeVM);
        }

        public async Task<IActionResult> AddBasket(int? id)
        {
            if (id == null) return NotFound();
            Product product =await _db.Products.FindAsync(id);
            if (product == null) return NotFound();

            List<BasketVM> products;
            string existBasket = Request.Cookies["basket"];
            if (existBasket == null)
            {
                products = new List<BasketVM>();
            }
            else
            {
                products = JsonConvert.DeserializeObject<List<BasketVM>>(existBasket);
            }

            BasketVM existProduct = products.FirstOrDefault(p => p.Id == id);
            if (existProduct == null)
            {
                BasketVM newProduct = new BasketVM
                {
                    Id = product.Id,
                    Count = 1
                };
                products.Add(newProduct);
            }
            else
            {
                existProduct.Count++;
            }

            
            string basket = JsonConvert.SerializeObject(products);
            Response.Cookies.Append("basket", basket, new CookieOptions { MaxAge = TimeSpan.FromDays(14) });

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Basket()
        {
            //string session = HttpContext.Session.GetString("group");
            //string cookie = Request.Cookies["name"];
            //return Content(session+" "+cookie);

            string basket= Request.Cookies["basket"];
            List<BasketVM> products=new List<BasketVM>();
            if (basket != null)
            {
                products = JsonConvert.DeserializeObject<List<BasketVM>>(basket);
                foreach (BasketVM item in products)
                {
                    Product dbProduct = await _db.Products.FindAsync(item.Id);
                    item.Price = dbProduct.Price;
                    item.Image = dbProduct.Image;
                    item.Title = dbProduct.Title;
                }
            }
            
            return View(products);
        }
    }
}